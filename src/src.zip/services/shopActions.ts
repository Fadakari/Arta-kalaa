import api from "./api";

// ─── Helper ──────────────────────────────────────
function mergeProductsWithDiscounts(
  products: any[],
  discountedProducts: any[]
): any[] {
  if (!discountedProducts?.length) return products;

  const discountMap = new Map(
    discountedProducts.map((item: any) => [item.slug, item])
  );

  return products.map((product: any) => {
    const discount = discountMap.get(product.slug);
    return discount
      ? {
          ...product,
          isDiscounted: true,
          discount_percentage: discount.discount_percentage,
          final_price: discount.final_price,
        }
      : { ...product, isDiscounted: false };
  });
}

function buildQueryString(params?: any, page?: number): string {
  const query = new URLSearchParams();

  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== "") {
        query.append(key, String(value));
      }
    });
  }

  if (page) query.append("page", String(page));
  return query.toString();
}

// ✅ اصلاح‌شده - فقط data رو برمی‌گردونه
export async function GetProducts(
  params?: any,
  page?: number,
  onlyDiscounted?: boolean
) {
  try {
    const queryString = buildQueryString(params, page);

    if (onlyDiscounted) {
      const resDiscounted = await api.get(
        `/home/discounted-products/?${queryString}`
      );
      // فقط data رو برگردون
      return {
        results: resDiscounted.data?.results || [],
        count: resDiscounted.data?.count || 0,
        next: resDiscounted.data?.next || null,
        previous: resDiscounted.data?.previous || null,
      };
    }

    const [resNormal, resDiscounted] = await Promise.all([
      api.get(`/shop/products?${queryString}`),
      api.get("/home/discounted-products/"),
    ]);

    const normalData = resNormal.data;
    const discountedList = resDiscounted.data || [];

    // فقط data رو برگردون
    return {
      count: normalData?.count || 0,
      next: normalData?.next || null,
      previous: normalData?.previous || null,
      results: mergeProductsWithDiscounts(
        normalData?.results || [],
        discountedList
      ),
    };
  } catch (error) {
    console.error("GetProducts error:", error);
    return {
      count: 0,
      next: null,
      previous: null,
      results: [],
    };
  }
}

// ✅ اصلاح‌شده - فقط data رو برمی‌گردونه
export async function GetLatestProducts() {
  try {
    const [resLatest, resDiscounted] = await Promise.all([
      api.get("/shop/latest-products"),
      api.get("/home/discounted-products/"),
    ]);

    const latestData = resLatest.data;
    const latestProducts = latestData?.latest_products || [];
    const discountedList = resDiscounted.data || [];

    // فقط data رو برگردون
    return {
      results: mergeProductsWithDiscounts(latestProducts, discountedList),
    };
  } catch (error) {
    console.error("GetLatestProducts error:", error);
    return { results: [] };
  }
}

// ✅ اصلاح‌شده - فقط data رو برمی‌گردونه
export async function GetFeaturedProducts() {
  try {
    const result = await api.get("/shop/featured-products");
    // فقط data رو برگردون
    return result.data || [];
  } catch (error) {
    console.error("GetFeaturedProducts error:", error);
    return [];
  }
}

export async function GetShopCategoriesTreeList() {
  try {
    const result = await api.get("/shop/categories/tree/");
    return result;
  } catch (error) {
    console.error("GetShopCategoriesTreeList error:", error);
    return null;
  }
}

export async function GetProductBySlug(slug: string) {
  try {
    const productRes = await api.get(`/shop/products/${slug}/`);
    const product = productRes.data;

    try {
      const discountRes = await api.get(
        `/home/discounted-products/${slug}/`
      );
      return {
        ...product,
        isDiscounted: true,
        final_price: discountRes.data.final_price,
        discount_percentage: discountRes.data.discount_percentage,
      };
    } catch {
      return { ...product, isDiscounted: false };
    }
  } catch (error) {
    console.error("GetProductBySlug error:", error);
    return null;
  }
}

// ─── Cart (بدون تغییر) ──────────────────────────
export async function GetShopCartList() {
  try {
    const res = await fetch("/internal-api/shop/cart", {
      method: "GET",
      cache: "no-store",
    });
    if (!res.ok) throw new Error("خطا در دریافت سبد خرید");
    return await res.json();
  } catch (error) {
    console.error("GetShopCartList error:", error);
    return null;
  }
}

export async function PostShopCart(item: {
  product_id: number;
  quantity: number;
  is_discounted?: boolean;
  store_name_english?: string;
  color_id?: number | null;
  material_id?: number | null;
}) {
  try {
    const res = await fetch("/internal-api/shop/cart/", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(item),
    });
    const data = await res.json();
    if (!res.ok) return { error: data.error || "خطا در افزودن به سبد خرید" };
    return data;
  } catch (error: any) {
    return { error: error.message || "خطا در ارتباط با سرور" };
  }
}

export async function PatchShopCart(
  id: number,
  data: { quantity: number; is_discounted?: boolean }
) {
  const url = data?.is_discounted
    ? "/internal-api/shop/discounted-cart/"
    : "/internal-api/shop/cart/";
  try {
    const res = await fetch(url, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, ...data }),
    });
    const result = await res.json();
    if (!res.ok) return { error: result?.error || "خطا در بروزرسانی" };
    return result;
  } catch (error: any) {
    return { error: error.message };
  }
}

export async function DeleteShopCart(id: string, is_discounted?: boolean) {
  const url = is_discounted ? "/internal-api/shop/discounted-cart" : "/internal-api/shop/cart";
  try {
    const res = await fetch(`${url}?id=${encodeURIComponent(id)}`, { method: "DELETE" });
    if (!res.ok) throw new Error("Failed to delete");
    return await res.json();
  } catch (error) {
    console.error("DeleteShopCart error:", error);
    return null;
  }
}

export async function ClearShopCart() {
  try {
    const res = await fetch("/internal-api/shop/cart/clear", { method: "DELETE" });
    if (!res.ok) throw new Error("Failed to clear");
    return await res.json();
  } catch (error) {
    console.error("ClearShopCart error:", error);
    return null;
  }
}

// ─── Orders (بدون تغییر) ────────────────────────
export async function createDiscountedOrder(data: any) {
  try {
    const res = await fetch("/internal-api/shop/order/discounted", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    const json = await res.json();
    return {
      success: res.ok,
      data: json,
      message: json.message || (res.ok ? "سفارش ثبت شد" : "خطا"),
    };
  } catch (error: any) {
    return { success: false, message: error.message || "خطای ناشناخته" };
  }
}

export async function createNormalOrder(data: any) {
  try {
    const res = await fetch("/internal-api/shop/order/normal", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    const json = await res.json();
    return {
      success: res.ok,
      data: json,
      message: json.message || (res.ok ? "سفارش ثبت شد" : "خطا"),
    };
  } catch (error: any) {
    return { success: false, message: error.message || "خطای ناشناخته" };
  }
}

export async function marketing_create_order(data: any, store_name_english: string) {
  try {
    const res = await fetch(
      `${process.env.NEXT_PUBLIC_SITE_URL}/internal-api/marketing/store/${store_name_english}/order/create`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      }
    );
    const json = await res.json();
    return {
      success: res.ok,
      data: json,
      message: json.message || (res.ok ? "سفارش ثبت شد" : "خطا"),
    };
  } catch (error: any) {
    return { success: false, message: error.message || "خطای ناشناخته" };
  }
}

export async function goToGateways(id: number | string) {
  try {
    const res = await fetch(`/internal-api/shop/pay/${id}`, {
      method: "POST",
      credentials: "include",
    });
    if (!res.ok) throw new Error("خطا در اتصال به درگاه");
    const result = await res.json();
    if (result.tc) localStorage.setItem("tc", result.tc);
    if (result.gateway_url) {
      const { url, params, method } = result.gateway_url;
      if (method === "GET") {
        window.location.href = `${url}?${new URLSearchParams(params)}`;
      } else {
        const form = document.createElement("form");
        form.method = method;
        form.action = url;
        form.style.display = "none";
        Object.entries(params).forEach(([key, value]) => {
          const input = document.createElement("input");
          input.type = "hidden";
          input.name = key;
          input.value = String(value);
          form.appendChild(input);
        });
        document.body.appendChild(form);
        form.submit();
      }
    }
  } catch (err) {
    console.error("Payment error:", err);
    alert("خطا در اتصال به درگاه پرداخت");
  }
}

export async function GetShippingServices() {
  try {
    const result = await api.get("/shop/shipping-services");
    return result;
  } catch (error) {
    console.error("GetShippingServices error:", error);
    return null;
  }
}

export async function GetComments(product_id: number) {
  try {
    const response = await api.get(`/shop/products/${product_id}/comments/`);
    return response.data;
  } catch (error) {
    console.error("GetComments error:", error);
    return [];
  }
}

export async function PostComment(
  product_id: number,
  data: { text: string; parent?: number | null }
) {
  const res = await fetch(`/internal-api/shop/comments/${product_id}/`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const error = await res.json();
    throw new Error(error?.message || "ارسال نظر با خطا مواجه شد");
  }
  return res.json();
}

export async function DeleteComment(commentId: number) {
  const res = await fetch(`/internal-api/shop/comments/delete/${commentId}`, {
    method: "DELETE",
  });
  if (!res.ok) {
    const data = await res.json();
    throw new Error(data.error || "خطا در حذف نظر");
  }
  return true;
}