import axios, { AxiosInstance, AxiosError, InternalAxiosRequestConfig } from "axios";
import https from "https";

const api: AxiosInstance = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL || "",
  timeout: 8000, // ۸ ثانیه ← کمتر
  headers: {
    "Content-Type": "application/json",
  },
  withCredentials: false,
  httpsAgent: new https.Agent({
    rejectUnauthorized: false,
  }),
});

api.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    if (process.env.NODE_ENV === "development") {
      console.log(`[API] ${config.method?.toUpperCase()} ${config.url}`);
    }
    return config;
  },
  (error: AxiosError) => Promise.reject(error)
);

api.interceptors.response.use(
  (response) => response,
  async (error: AxiosError) => {
    const config = error.config as any;
    config.__retryCount = config.__retryCount || 0;

    // فقط ۱ بار retry ← کمتر
    if (!error.response && config.__retryCount < 1) {
      config.__retryCount++;
      await new Promise((resolve) => setTimeout(resolve, 500)); // ۰.۵ ثانیه صبر
      return api(config);
    }

    if (process.env.NODE_ENV === "development") {
      console.error(`[API Error] ${error.config?.url} - ${error.message}`);
    }

    return Promise.reject(error);
  }
);

export default api;

export class ApiError extends Error {
  constructor(
    message: string,
    public statusCode: number = 500,
    public details?: any
  ) {
    super(message);
    this.name = "ApiError";
  }
}

export async function fetchWithErrorHandling<T = any>(
  url: string,
  options?: RequestInit
): Promise<T> {
  try {
    const response = await fetch(url, {
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers,
      },
    });

    const data = await response.json();

    if (!response.ok) {
      throw new ApiError(
        data?.error || data?.message || "خطا در ارتباط با سرور",
        response.status,
        data?.errors || data
      );
    }

    return data;
  } catch (error) {
    if (error instanceof ApiError) throw error;
    throw new ApiError("خطا در ارتباط با سرور", 500);
  }
}