import Article from "@/types/blog";
import { BlogCategoryNode } from "@/types/categories";
import api from "./api";

type BlogPostsResponse = {
  data: Article[];
  next_page: string | null;
  total_pages: number;
};

interface BlogPostsParams {
  category?: string;
}

interface SearchParams {
  search?: string;
  sort?: string;
  page?: number;
  category_id?: number;
}

export async function GetBlogPosts(
  params?: BlogPostsParams,
  page?: string
): Promise<BlogPostsResponse | undefined> {
  try {
    const query = new URLSearchParams();
    if (params?.category) query.append("category", params.category);
    if (page) query.append("page", page);

    const result = await api.get<BlogPostsResponse>(
      `/blog/posts/?${query.toString()}`
    );
    return result.data;
  } catch (error) {
    console.error("GetBlogPosts error:", error);
    return undefined;
  }
}

export async function GetLatestBlogPosts() {
  try {
    const result = await api.get("/blog/posts/latest");
    return result.data;
  } catch (error) {
    console.error("GetLatestBlogPosts error:", error);
    return undefined;
  }
}

export async function GetBlogCategoriesMenuStructure(): Promise<
  BlogCategoryNode[] | undefined
> {
  try {
    const result = await api.get<BlogCategoryNode[]>(
      "/blog/categories/menu_structure/"
    );
    return result.data;
  } catch (error) {
    console.error("GetBlogCategoriesMenuStructure error:", error);
    return undefined;
  }
}

export async function GetBlogBySlug(slug: string) {
  try {
    const result = await api.get(`/blog/posts/${slug}/`);
    return result.data;
  } catch (error) {
    console.error("GetBlogBySlug error:", error);
    return null;
  }
}

export async function SearchBlogs(params: SearchParams) {
  try {
    const query = new URLSearchParams();
    if (params?.search) query.append("q", params.search);
    if (params?.sort) query.append("sort", params.sort);
    if (params?.page !== undefined) query.append("page", params.page.toString());
    if (params?.category_id !== undefined)
      query.append("category", params.category_id.toString());

    const result = await api.get(`/blog/posts/search?${query.toString()}`);
    return result.data;
  } catch (error) {
    console.error("SearchBlogs error:", error);
    return null;
  }
}

// ✅✅✅ اینو حتماً اصلاح کن - فقط data رو برگردون
export async function GetLatestArticles() {
  try {
    const result = await api.get("/blog/posts/latest");
    // فقط data رو برگردون، نه کل result
    return result.data;
  } catch (error) {
    console.error("GetLatestArticles error:", error);
    return null;
  }
}