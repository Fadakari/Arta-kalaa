import { addToast } from "@heroui/toast";
import api, { fetchWithErrorHandling, ApiError } from "./api";

// ─── Helper ──────────────────────────────────────
function showToast(
  title: string,
  options?: {
    description?: string;
    color?: "success" | "danger" | "warning";
  }
) {
  try {
    addToast({
      title,
      description: options?.description,
      color: options?.color || "success",
    });
  } catch {
    console.log(`[Toast] ${title}`);
  }
}

// ─── Auth Actions ────────────────────────────────
export const login = async (phone_number: string, password: string) => {
  try {
    const data = await fetchWithErrorHandling<any>(
      "/internal-api/auth/login",
      {
        method: "POST",
        body: JSON.stringify({ phone_number, password }),
        credentials: "include",
      }
    );

    showToast(data.message || "ورود با موفقیت انجام شد");
    location.reload();
    
    return data;
  } catch (error) {
    const message =
      error instanceof ApiError ? error.message : "خطا در ورود به حساب";
    showToast(message, { color: "danger" });
    throw error;
  }
};

export const sendOtp = async (phone_number: string) => {
  try {
    const result = await api.post("/users/otp/request/", { phone_number });

    if (result.status === 200) {
      showToast("کد تایید با موفقیت به شماره تلفن شما ارسال شد", {
        description: phone_number,
      });
      return result;
    } else if (result.status === 400) {
      showToast("شماره تلفن باید ۱۱ رقم باشد", {
        description: phone_number,
        color: "danger",
      });
    }

    return result;
  } catch (error: any) {
    const message = error?.response?.data?.message || "خطا در ارسال کد تایید";
    showToast(message, { color: "danger" });
    console.error("sendOtp error:", error);
  }
};

export const verifyOtp = async (
  phone_number: string,
  code: string,
  referral_code?: string
) => {
  try {
    const data = await fetchWithErrorHandling<any>(
      "/internal-api/auth/verify-otp",
      {
        method: "POST",
        body: JSON.stringify({ phone_number, code, referral_code }),
        credentials: "include",
      }
    );

    showToast(data.message || "احراز هویت با موفقیت انجام شد");
    location.reload();
    
    return data;
  } catch (error) {
    const message =
      error instanceof ApiError
        ? error.message
        : "کد تایید نامعتبر یا منقضی شده است";
    showToast(message, {
      description: "لطفاً دوباره تلاش کنید",
      color: "danger",
    });
  }
};

export async function checkPhoneExists(phone: string) {
  try {
    const res = await api.post("/users/check-user-status/", {
      phone_number: phone,
    });
    return res.data?.has_password;
  } catch (error) {
    console.error("checkPhoneExists error:", error);
    return false;
  }
}