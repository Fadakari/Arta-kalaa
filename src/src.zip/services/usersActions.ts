import { fetchWithErrorHandling, ApiError } from "./api";

// ─── User Actions ────────────────────────────────
export const editInfo = async (data: any) => {
  try {
    const response = await fetch("/internal-api/users/edit", {
      method: "PATCH",
      body: JSON.stringify(data),
      headers: { "Content-Type": "application/json" },
    });

    const result = await response.json();

    if (!response.ok) {
      return {
        success: false,
        errors: result.errors || {},
        message: result.message || "خطایی رخ داده است",
      };
    }

    return {
      success: true,
      data: result,
      message: "اطلاعات با موفقیت بروزرسانی شد",
    };
  } catch (error) {
    console.error("editInfo error:", error);
    return {
      success: false,
      errors: {},
      message: "خطا در ارتباط با سرور",
    };
  }
};

export const changePassword = async (data: any) => {
  try {
    const response = await fetch(
      "/internal-api/users/change-password",
      {
        method: "POST",
        body: JSON.stringify(data),
        headers: { "Content-Type": "application/json" },
      }
    );

    const result = await response.json();

    if (!response.ok) {
      return {
        success: false,
        errors: result.errors || {},
        message: result.message || "خطایی رخ داده است",
      };
    }

    return {
      success: true,
      data: result,
      message: "رمز عبور با موفقیت تغییر کرد",
    };
  } catch (error) {
    console.error("changePassword error:", error);
    return {
      success: false,
      errors: {},
      message: "خطا در ارتباط با سرور",
    };
  }
};

export async function GenDiscount(data: { order_amount: number }) {
  try {
    const response = await fetch("/internal-api/users/discount", {
      method: "POST",
      body: JSON.stringify(data),
      headers: { "Content-Type": "application/json" },
    });

    const result = await response.json();

    if (!response.ok) {
      return {
        success: false,
        errors: result.errors || {},
        message: result.message || "خطایی رخ داده است",
      };
    }

    return {
      success: true,
      data: result.data,
    };
  } catch (error) {
    console.error("GenDiscount error:", error);
    return {
      success: false,
      errors: {},
      message: "خطا در ارتباط با سرور",
    };
  }
}