"use client";

import Card from "@/components/Products/Card";
import QuickBlogCard from "@/components/QuickBlogCard";
import Slider from "@/components/Slider";
import SectionHeader from "@/components/Home/SectionHeader";
import Link from "next/link";
import { useHomePage } from "@/hooks/useHomePage";
import { BlogCategory } from "@/types";

interface HomePageClientProps {
  blogCategories: BlogCategory[];
}

export function HomePageClient({ blogCategories }: HomePageClientProps) {
  const {
    products,
    latestProducts,
    featuredProducts,
    latestArticles,
    isLoading,
    error,
  } = useHomePage();

  // 🔍 DEBUG
  console.log("🏠 HomePageClient render:", {
    products: products.length,
    latestProducts: latestProducts.length,
    featuredProducts: featuredProducts.length,
    latestArticles: latestArticles.length,
    isLoading,
    error,
  });

  if (error) {
    return (
      <div className="max-w-[1470px] mx-auto px-4 sm:px-6 text-center py-12">
        <div className="bg-red-50 text-red-600 rounded-2xl p-6">
          <p className="text-lg font-medium">{error}</p>
          <button
            onClick={() => window.location.reload()}
            className="mt-4 px-6 py-2 bg-red-600 text-white rounded-xl hover:bg-red-700 transition-colors"
          >
            تلاش مجدد
          </button>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="max-w-[1470px] mx-auto px-4 sm:px-6 space-y-8">
        {[1, 2, 3].map((i) => (
          <div key={i} className="rounded-3xl bg-white p-6 shadow-lg">
            <div className="skeleton h-10 w-48 rounded-xl mb-6" />
            <div className="grid grid-cols-4 gap-6">
              {[1, 2, 3, 4].map((j) => (
                <div key={j} className="skeleton h-64 rounded-2xl" />
              ))}
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <>
      {/* محصولات تخفیف‌دار */}
      {products.length > 0 && (
        <section className="relative mt-32">
          <div className="absolute inset-0 bg-gradient-to-b from-blue-600 to-blue-700 h-48 -z-10" />
          <div className="max-w-[1470px] mx-auto px-4 sm:px-6 -mt-20">
            <div className="bg-white rounded-3xl shadow-2xl p-8 ring-1 ring-black/5">
              <Slider
                spaceBetween={20}
                slidesPerView={4}
                items={products}
                Card={Card}
                customNavigation
                className="!text-primary"
              />
            </div>
          </div>
        </section>
      )}

      {/* جدیدترین محصولات */}
      {latestProducts.length > 0 ? (
        <section className="max-w-[1470px] mx-auto px-4 sm:px-6">
          <div className="relative rounded-3xl border-2 border-gray-100/80 bg-white/80 backdrop-blur-sm p-6 shadow-lg">
            <SectionHeader
              title="محصولات"
              highlight="جدیدترین"
              linkHref="/products?sort=newest"
            />
            <div className="px-4 mt-6">
              <Slider
                spaceBetween={35}
                items={latestProducts}
                Card={Card}
                className="!text-primary"
              />
            </div>
          </div>
        </section>
      ) : (
        <div className="max-w-[1470px] mx-auto px-4 sm:px-6 text-center py-8">
          <p className="text-gray-400">🔍 جدیدترین محصولات: {latestProducts.length} عدد</p>
        </div>
      )}

      {/* پرفروش‌ترین محصولات */}
      {featuredProducts.length > 0 && (
        <section className="max-w-[1470px] mx-auto px-4 sm:px-6">
          <div className="relative rounded-3xl border-2 border-gray-100/80 bg-white/80 backdrop-blur-sm p-6 shadow-lg">
            <SectionHeader
              title="محصولات"
              highlight="پرفروش ترین"
              linkHref="/products?sort=popular"
            />
            <div className="px-4 mt-6">
              <Slider
                spaceBetween={35}
                items={featuredProducts}
                Card={Card}
                className="!text-primary"
              />
            </div>
          </div>
        </section>
      )}

      {/* مقالات وبلاگ */}
      {latestArticles.length > 0 && (
        <section className="max-w-[1470px] mx-auto px-4 sm:px-6">
          <div className="relative rounded-3xl border-2 border-gray-100/80 bg-white/80 backdrop-blur-sm p-6 shadow-lg overflow-hidden">
            <div className="flex flex-col lg:flex-row gap-8">
              <div className="w-full lg:w-1/3">
                <SectionHeader
                  title="وبلاگ"
                  highlight="آخرین مطالب"
                  linkHref="/articles"
                />
                <nav className="hidden lg:flex flex-col gap-3 mt-4" aria-label="دسته‌بندی مقالات">
                  {blogCategories.map((cat) => (
                    <Link
                      key={cat.id}
                      href={`/articles?category=${cat.slug}`}
                      className="group relative font-semibold text-gray-700 hover:text-blue-600 transition-colors py-2 px-4 rounded-xl hover:bg-blue-50"
                    >
                      <span className="flex items-center gap-2">
                        <span className="w-2 h-2 bg-blue-500 rounded-full opacity-0 group-hover:opacity-100 transition-all" />
                        {cat.title}
                      </span>
                      <span className="absolute bottom-0 right-4 left-4 h-0.5 bg-gradient-to-r from-blue-500 to-transparent scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-right" />
                    </Link>
                  ))}
                </nav>
              </div>
              <div className="w-full lg:w-2/3">
                <Slider
                  items={latestArticles}
                  Card={QuickBlogCard}
                  spaceBetween={20}
                  slidesPerView={2.2}
                  className="!text-primary"
                />
              </div>
            </div>
          </div>
        </section>
      )}
    </>
  );
}