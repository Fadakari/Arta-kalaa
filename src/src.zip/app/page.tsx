import { Metadata } from "next";
import Brand from "@/components/Brand";
import QuickBlogCard from "@/components/QuickBlogCard";
import Slider from "@/components/Slider";
import Card from "@/components/Products/Card";
import HomeSlider from "@/components/HomeSlider";
import FeatureCard from "@/components/home/FeatureCard";
import CategoryCard from "@/components/home/CategoryCard";
import SectionHeader from "@/components/home/SectionHeader";
import { GetShopCategoriesTreeList } from "@/services/shopActions";
import { GetBlogCategoriesMenuStructure } from "@/services/blogActions";
import { homeSliderList } from "@/services/homeActions";
import { HomePageClient } from "./HomePageClient";
import { FEATURES, BRANDS, METADATA_CONFIG } from "@/constants/home";
import { ImageType, SliderImage } from "@/types";

export const metadata: Metadata = {
  title: METADATA_CONFIG.title,
  description: METADATA_CONFIG.description,
  keywords: METADATA_CONFIG.keywords,
  openGraph: {
    title: "آرتا کالا",
    description: "خرید آنلاین با تضمین کیفیت و ارسال سریع از آرتا کالا",
    url: `${process.env.NEXT_PUBLIC_SITE_URL}`,
    siteName: "آرتا کالا",
    images: [
      {
        url: `${process.env.NEXT_PUBLIC_SITE_URL}/opengraph-image.jpg`,
        width: 1200,
        height: 630,
        alt: "آرتا کالا",
      },
    ],
    locale: "fa_IR",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "آرتا کالا",
    description: "خرید آنلاین با تضمین کیفیت و ارسال سریع از آرتا کالا",
    images: [`${process.env.NEXT_PUBLIC_SITE_URL}/opengraph-image.jpg`],
  },
};

export default async function Home() {
  const [shopCategoriesResult, blogCategoriesResult, slidersResult] = 
    await Promise.allSettled([
      GetShopCategoriesTreeList(),
      GetBlogCategoriesMenuStructure(),
      homeSliderList(),
    ]);

  const shopCategories = 
    shopCategoriesResult.status === "fulfilled" 
      ? shopCategoriesResult.value?.data || [] 
      : [];
      
  const blogCategories = 
    blogCategoriesResult.status === "fulfilled" 
      ? blogCategoriesResult.value?.slice(0, 4) || [] 
      : [];
  
  const sliders = 
    slidersResult.status === "fulfilled" 
      ? slidersResult.value || [] 
      : [];

  const sliderImages: SliderImage[] = Array.isArray(sliders)
    ? sliders
        .sort((a: ImageType, b: ImageType) => (a.order || 0) - (b.order || 0))
        .map((item: ImageType) => ({
          id: item.id,
          src: item.image,
          alt: `بنر تبلیغاتی شماره ${item.order || ""}`,
        }))
    : [];

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {sliderImages.length > 0 && (
        <header className="relative max-w-[1470px] py-6 mx-auto px-4">
          <div className="w-full overflow-hidden rounded-3xl shadow-2xl ring-1 ring-black/5">
            <HomeSlider images={sliderImages} />
          </div>
          <div className="absolute -top-10 -left-10 w-40 h-40 bg-blue-500/10 rounded-full blur-3xl -z-10" />
          <div className="absolute -bottom-10 -right-10 w-60 h-60 bg-blue-500/5 rounded-full blur-3xl -z-10" />
        </header>
      )}

      <h1 className="sr-only">
        آرتا کالا | فروشگاه آنلاین ابزار با تضمین کیفیت
      </h1>

      <main className="space-y-8 pb-20">
        {/* ویژگی‌ها */}
        <section className="max-w-[1470px] mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {FEATURES.map((feature, index) => (
              <FeatureCard key={index} feature={feature} index={index} />
            ))}
          </div>
        </section>

        {/* برندها */}
        <section className="relative max-w-[1470px] mx-auto px-4 sm:px-6">
          <div className="relative overflow-hidden rounded-3xl bg-blue-50/60 p-8 shadow-lg border border-blue-100">
            <div className="absolute -top-20 -right-20 w-60 h-60 bg-blue-200/30 rounded-full blur-3xl" />
            <div className="absolute -bottom-20 -left-20 w-60 h-60 bg-blue-200/30 rounded-full blur-3xl" />
            
            <div className="relative text-center mb-8">
              <span className="inline-block px-4 py-1.5 bg-blue-100/80 rounded-full text-xs font-medium text-blue-600 mb-3">
                برندهای برتر
              </span>
              <h3 className="text-2xl lg:text-3xl font-bold text-gray-800">
                معتبرترین <span className="text-blue-500">برندها</span> در آرتاکالا
              </h3>
            </div>

            <div className="relative px-2">
              <Slider
                spaceBetween={30}
                items={BRANDS}
                Card={Brand}
                navigation={true}
                slidesPerView={5}
              />
            </div>

            <div className="relative text-center mt-6">
              <p className="text-blue-400 text-sm">
                و ده‌ها برند معتبر دیگر...
              </p>
            </div>
          </div>
        </section>

        {/* دسته‌بندی محصولات */}
        {shopCategories.length > 0 && (
          <section className="relative max-w-[1470px] mx-auto px-4 sm:px-6">
            <div className="relative overflow-hidden rounded-3xl bg-blue-50/60 p-8 shadow-lg border border-blue-100">
              <div className="absolute -top-20 -right-20 w-60 h-60 bg-blue-200/30 rounded-full blur-3xl" />
              <div className="absolute -bottom-20 -left-20 w-60 h-60 bg-blue-200/30 rounded-full blur-3xl" />
              
              <div className="relative">
                <SectionHeader title="محصولات" highlight="دسته بندی" />
                <nav
                  aria-label="دسته‌بندی‌های سریع"
                  className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 place-items-center py-4"
                >
                  {shopCategories.slice(0, 6).map((cat: any) => (
                    <CategoryCard key={cat.id} category={cat} />
                  ))}
                </nav>
              </div>
            </div>
          </section>
        )}

        {/* کلاینت کامپوننت */}
        <HomePageClient blogCategories={blogCategories} />
      </main>
    </div>
  );
}