"use client";

import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import clsx from "clsx";
import { CategoryNode } from "@/types/categories";
import { useUser } from "../context/UserContext";
import { useAuthModal } from "../context/AuthModalProvider";
import { useCategories } from "../context/CategoriesContext";
import { useCart } from "../context/CartContextProvider";
import SearchBox from "./SearchBox";
import UserDropdown from "./UserMenu";
import { User } from "@/types/user";
import { convertNumberToPersian } from "@/utils/converNumbers";
import CartDrawer from "./CartDrawer";
import logo from "../../public/logo.png";

import { GoChevronLeft, GoChevronRight, GoChevronUp } from "react-icons/go";
import { RiMenu3Fill, RiCloseLine, RiUserLine } from "react-icons/ri";
import { FiPhoneCall } from "react-icons/fi";
import { CiLogin } from "react-icons/ci";
import { LogOutIcon, Truck, ShieldCheck, Headphones, Clock } from "lucide-react";

const NAV_LINKS = [
  { href: "/", label: "صفحه اصلی", icon: "🏠" },
  { href: "/products", label: "محصولات", icon: "🛍️" },
  { href: "/products/offers", label: "تخفیف‌ها", icon: "🔥", badge: "ویژه" },
  { href: "/articles", label: "مقالات", icon: "📝" },
  { href: "/about-us", label: "درباره ما", icon: "ℹ️" },
  { href: "/contact-info", label: "ارتباط با ما", icon: "📞" },
];

// ─── رندر دسته‌بندی (دقیقاً مثل کد قدیمی) ─────────────────
function RenderCategories({ categories }: { categories: CategoryNode[] }) {
  return (
    <ul className="relative">
      {Array.isArray(categories) && categories.length > 0 ? (
        categories.map((category) => (
          <li
            key={category.id}
            className="group relative hover:bg-black/5 whitespace-nowrap"
          >
            <Link
              href={`/products/?category_id=${category.id}`}
              className="font-normal flex items-center justify-between px-4 w-full h-full py-2.5"
            >
              {category.name}
              {category.children && category.children.length > 0 && (
                <GoChevronLeft className="size-4 text-gray-400" />
              )}
            </Link>

            {category.children && category.children.length > 0 && (
              <div className="absolute top-0 right-full bg-white text-[#3d464d] rounded-xl shadow-xl border border-gray-100 group-hover:visible group-hover:opacity-100 invisible opacity-0 transition-all duration-200 z-50 p-4 min-w-[500px]">
                <ul className="flex flex-wrap list-disc pr-5">
                  {category.children.map((child) => (
                    <li
                      key={child.id}
                      className="relative max-w-[25%] flex-[0_0_25%] w-full py-px"
                    >
                      <Link
                        href={`/products/?category_id=${child.id}`}
                        className="hover:text-blue-600 transition-colors block py-1.5 px-2"
                      >
                        {child.name}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </li>
        ))
      ) : (
        <div className="p-5 w-full text-center text-gray-400">دسته بندی وجود ندارد</div>
      )}
    </ul>
  );
}

// ─── MegaMenu ────────────────────────────────────
function MegaMenu({ categories }: { categories: CategoryNode[] }) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div
      className="relative shrink-0"
      onMouseEnter={() => setIsOpen(true)}
      onMouseLeave={() => setIsOpen(false)}
    >
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="group flex items-center gap-2 px-5 py-3 bg-blue-500 hover:bg-blue-600 text-white rounded-2xl font-bold text-sm transition-all duration-300 shadow-lg shadow-blue-500/25 hover:shadow-xl hover:-translate-y-0.5"
      >
        <RiMenu3Fill className="size-5" />
        <span className="hidden xl:inline">دسته‌بندی کالاها</span>
        <GoChevronUp className={`size-4 transition-transform duration-300 ${isOpen ? "rotate-0" : "rotate-180"}`} />
      </button>

      {isOpen && (
        <>
          <div className="absolute top-full right-0 mt-2 bg-white rounded-b-xl shadow-xl border border-gray-100 overflow-hidden z-50 w-[280px]">
            <RenderCategories categories={categories} />
          </div>
          <div
            className="fixed inset-0 bg-black/30 z-40"
            onClick={() => setIsOpen(false)}
          />
        </>
      )}
    </div>
  );
}

// ─── Main Navbar ─────────────────────────────────
export default function Navbar() {
  const categories = useCategories();
  const pathname = usePathname();
  const { onOpen: onAuthOpen }: any = useAuthModal();
  const { user } = useUser();
  const { cart } = useCart();
  const [isSticky, setIsSticky] = useState(false);
  const stickyRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!stickyRef.current) return;
    const stickyTop = stickyRef.current.offsetTop;
    const handleScroll = () => {
      setIsSticky(window.scrollY >= stickyTop);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header>
      {/* Header بالایی */}
      <div className="flex justify-between py-5 px-3 items-center container">
        <MobileDrawer onAuthOpen={onAuthOpen} user={user} links={NAV_LINKS} categories={categories} />
        
        <Link href="/" className="flex items-center gap-3 group">
          <Image src={logo} alt="آرتا کالا" title="آرتا کالا" width={160} height={40} placeholder="blur" />
        </Link>

        <div className="flex items-center gap-10">
          <div className="hidden lg:flex items-center gap-2 text-zinc-600 text-base lg:text-lg font-medium">
            <span className="font-semibold">شماره تماس:</span>
            <Link href="tel:03536264264" className="text-lg lg:text-xl font-semibold text-black hover:text-primary-700 transition-colors">
              035-36264264
            </Link>
          </div>
          <Link href="tel:03536264264" className="lg:hidden" aria-label="تماس با ما">
            <FiPhoneCall className="size-8 text-zinc-600" />
          </Link>
          <CartDrawer cart={cart} />
        </div>
      </div>

      {/* Navigation Bar */}
      <div
        ref={stickyRef}
        className={`z-50 min-h-[54px] backdrop-blur bg-primary/90 transition-all duration-300 shadow-md ${
          isSticky ? "fixed left-0 right-0 top-0" : "relative"
        }`}
      >
        <div className="container mx-auto w-full h-full">
          <div className="flex items-center justify-between relative h-full">
            <div className="hidden lg:flex items-center h-full">
              <MegaMenu categories={categories} />

              <nav className="mr-4 flex gap-2 text-xs lg:text-sm 2xl:text-base text-nowrap">
                {NAV_LINKS.map(({ href, label }) => (
                  <Link
                    key={href}
                    href={href}
                    className={clsx(
                      "p-2 rounded-xs transition-colors ease-out hover:bg-white/50 hover:text-[#3d464d] font-medium",
                      pathname === href ? "bg-white/70 font-bold" : "text-white"
                    )}
                  >
                    {label}
                  </Link>
                ))}
              </nav>
            </div>

            <div className="flex items-center w-full lg:w-auto gap-2">
              <SearchBox />
              <div className="flex justify-around w-1/2 lg:w-auto gap-1">
                {user?.identity ? (
                  <UserDropdown user={user} />
                ) : (
                  <button
                    onClick={onAuthOpen}
                    className="p-2.5 px-2.5 hidden lg:px-6 w-full font-bold rounded-full bg-white hover:bg-zinc-100 active:bg-zinc-200 transition-colors text-black text-center sm:flex text-nowrap items-center justify-center gap-1 sm:gap-3"
                    aria-label="ورود / عضویت"
                  >
                    <CiLogin className="size-5 md:size-6 stroke-1" />
                    <span>ورود</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {isSticky && <div style={{ height: stickyRef.current?.offsetHeight || 54 }} />}
    </header>
  );
}

// ─── Mobile Drawer ───────────────────────────────
export function MobileDrawer({
  categories,
  links,
  user,
  onAuthOpen,
}: {
  categories: CategoryNode[];
  links: any[];
  user: User | null;
  onAuthOpen: () => void;
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [stack, setStack] = useState<CategoryNode[][]>([]);
  const [titleStack, setTitleStack] = useState<string[]>([]);
  const [current, setCurrent] = useState<CategoryNode[] | null>(null);
  const [title, setTitle] = useState("منوی دسترسی");
  const isRoot = current === null;

  const handleBack = () => {
    const prev = stack[stack.length - 1];
    const prevTitle = titleStack[titleStack.length - 1];
    setStack((prevStack) => prevStack.slice(0, -1));
    setTitleStack((prevTitles) => prevTitles.slice(0, -1));
    setCurrent(prev ?? null);
    setTitle(prevTitle ?? "منوی دسترسی");
  };

  const handleEnter = (category: CategoryNode) => {
    if (category.children && category.children.length > 0) {
      setStack((prev) => [...prev, current ?? categories]);
      setCurrent(category.children);
      setTitle(category.name);
      setTitleStack((prev) => [...prev, title]);
    }
  };

  const displayCategories = current || categories;
  const name = user?.identity?.first_name && user?.identity?.last_name
    ? `${user.identity.first_name} ${user.identity.last_name}`
    : "بدون نام";
  const firstLetter = user?.identity?.first_name?.[0] || user?.identity?.phone_number?.[0] || "؟";
  const phone = user?.identity?.phone_number ?? "بدون شماره";

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="hover:bg-white/50 active:bg-white/50 p-2 rounded-sm lg:hidden text-zinc-600 transition-colors"
        aria-label="باز کردن منو"
      >
        <RiMenu3Fill className="w-8 h-8 sm:w-9 sm:h-9 md:w-10 md:h-10" />
      </button>

      {isOpen && (
        <div className="fixed inset-0 z-50 flex">
          <div className="absolute inset-0 bg-black/30" onClick={() => setIsOpen(false)} />
          <div className="relative w-full max-w-[340px] bg-white h-full flex flex-col shadow-2xl animate-slide-in-right">
            {/* Header */}
            <div className="bg-[#f3f3f3] border-b border-zinc-300 text-zinc-500 p-4">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-3">
                  {!isRoot && (
                    <button className="text-sm text-zinc-600 flex items-center gap-1" onClick={handleBack}>
                      <GoChevronRight className="size-8 text-zinc-500" />
                    </button>
                  )}
                  <p className="font-bold">{title}</p>
                </div>
                <button onClick={() => setIsOpen(false)}>
                  <RiCloseLine className="size-8" />
                </button>
              </div>
            </div>

            {/* Body */}
            <div className="flex-1 overflow-hidden relative">
              <AnimatePresence initial={false}>
                {stack.map((cats, index) => (
                  <motion.div
                    key={`level-${index}`}
                    initial={{ x: "100%" }}
                    animate={{ x: 0 }}
                    exit={{ x: "100%" }}
                    transition={{ duration: 0.3 }}
                    className="absolute inset-0 bg-white overflow-y-auto"
                    style={{ zIndex: index }}
                  >
                    <ul className="flex flex-col">
                      {cats.map((cat: CategoryNode) => (
                        <li key={cat.id} className="flex items-center justify-between border-b border-zinc-200 text-zinc-600 font-light py-3 px-4 active:opacity-50">
                          {cat.children && cat.children.length > 0 ? (
                            <button className="text-lg text-right w-full h-full" onClick={() => handleEnter(cat)}>
                              {cat.name}
                            </button>
                          ) : (
                            <Link
                              onClick={() => setIsOpen(false)}
                              href={`/products/?category_id=${cat.id}`}
                              className="text-lg text-right w-full h-full"
                            >
                              {cat.name}
                            </Link>
                          )}
                          {cat.children && cat.children.length > 0 && (
                            <GoChevronLeft className="text-zinc-400 size-9 font-bold absolute pointer-events-none left-3" />
                          )}
                        </li>
                      ))}
                    </ul>
                  </motion.div>
                ))}

                {current && (
                  <motion.div
                    key={`level-${stack.length}`}
                    initial={{ x: "-100%" }}
                    animate={{ x: 0 }}
                    exit={{ x: "-100%" }}
                    transition={{ duration: 0.3 }}
                    className="absolute inset-0 bg-white overflow-y-auto"
                    style={{ zIndex: stack.length }}
                  >
                    <ul className="flex flex-col">
                      {current.map((cat: CategoryNode) => (
                        <li key={cat.id} className="flex items-center justify-between border-b border-zinc-200 text-zinc-600 font-light py-3 px-4 active:opacity-50">
                          {cat.children && cat.children.length > 0 ? (
                            <button className="text-lg text-right w-full h-full" onClick={() => handleEnter(cat)}>
                              {cat.name}
                            </button>
                          ) : (
                            <Link
                              onClick={() => setIsOpen(false)}
                              href={`/products/?category_id=${cat.id}`}
                              className="text-lg text-right w-full h-full"
                            >
                              {cat.name}
                            </Link>
                          )}
                          {cat.children && cat.children.length > 0 && (
                            <GoChevronLeft className="text-zinc-400 size-9 font-bold absolute pointer-events-none left-3" />
                          )}
                        </li>
                      ))}
                    </ul>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Links */}
            <div className="border-t border-zinc-200">
              {links.map((link: any) => (
                <Link
                  key={link.href}
                  onClick={() => setIsOpen(false)}
                  className="border-b border-zinc-200 text-zinc-600 font-light pt-3 pb-4 px-4 flex justify-between items-center text-lg active:opacity-50"
                  href={link.href}
                >
                  {link.label}
                </Link>
              ))}
            </div>

            {/* Footer */}
            <div className="p-4 bg-gray-50">
              {user?.identity ? (
                <div className="flex items-center justify-between w-full">
                  <div className="flex flex-row gap-3 w-full">
                    <div className="size-14 text-xl ring-4 ring-primary-100 flex items-center justify-center rounded-full bg-primary text-white font-bold">
                      {firstLetter}
                    </div>
                    <div>
                      <p className="font-semibold text-base">{name}</p>
                      <p className="text-sm text-gray-500">{convertNumberToPersian(phone)}</p>
                    </div>
                  </div>
                  <button
                    className="bg-danger/10 text-danger p-3 rounded-xl"
                    onClick={async () => {
                      await fetch("/internal-api/auth/logout/", { method: "POST", credentials: "include" });
                      location.replace("/");
                    }}
                  >
                    <LogOutIcon className="size-5" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => { setIsOpen(false); onAuthOpen(); }}
                  className="w-full btn-primary rounded-xl text-center font-semibold flex items-center justify-center gap-2"
                >
                  <CiLogin className="size-6" />
                  ورود / عضویت
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}