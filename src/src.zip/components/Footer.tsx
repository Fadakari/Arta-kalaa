"use client";

import Link from "next/link";
import React from "react";
import {
  FaPhoneAlt,
  FaWhatsapp,
  FaInstagram,
  FaMapMarkerAlt,
  FaChevronLeft,
  FaEnvelope,
  FaTelegram,
  FaLinkedinIn,
} from "react-icons/fa";
import { HiOutlineMail } from "react-icons/hi";
import { TbClockHour4 } from "react-icons/tb";

const footerData = {
  contact: {
    phone: "۰۳۵-۳۶۲۶۴۲۶۴",
    mobile: "۰۹۱۳۰۱۷۶۵۷۴",
    address: "یزد، خیابان شهید رجایی، نبش کوچه ۳۰، آرتاکالا",
    email: "info@artakala.ir",
    workingHours: "روزهای کاری ۱۰ تا ۲۰",
  },
  quickLinks: [
    { href: "/products?discounted=true", label: "تخفیف‌ها" },
    { href: "/products?featured=true", label: "پرفروش‌ها" },
    { href: "/articles", label: "مقالات" },
    { href: "/about-us", label: "درباره ما" },
    { href: "/contact-info", label: "تماس با ما" },
  ],
  importantLinks: [
    { href: "/", label: "صفحه اصلی" },
    { href: "/products", label: "فروشگاه" },
    { href: "/about-us", label: "درباره ما" },
    { href: "/contact-info", label: "تماس با ما" },
    { href: "/blog", label: "وبلاگ" },
  ],
  social: [
    {
      href: "https://www.instagram.com/arta_kalaa",
      icon: <FaInstagram />,
      label: "اینستاگرام",
    },
    {
      href: "https://api.whatsapp.com/send?phone=989199750828",
      icon: <FaWhatsapp />,
      label: "واتساپ",
    },
    {
      href: "https://t.me/artakala",
      icon: <FaTelegram />,
      label: "تلگرام",
    },
    {
      href: "https://www.linkedin.com/company/artakala",
      icon: <FaLinkedinIn />,
      label: "لینکدین",
    },
  ],
};

function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="relative w-full bg-gradient-to-b from-gray-900 via-gray-900 to-gray-950 text-white">
      {/* دکوراسیون بالای فوتر - خط رنگین کمانی */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-400" />
      
      {/* الگوی پس‌زمینه */}
      <div className="absolute inset-0 opacity-5 pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_30%_20%,rgba(255,255,255,0.1)_0%,transparent_50%)]" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        
        {/* لوگو و متن فرهنگی */}
        <div className="flex flex-col items-center text-center mb-16">
          <Link href="/" className="inline-block mb-8 group">
            <h2 className="text-5xl font-bold bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-400 bg-clip-text text-transparent group-hover:scale-105 transition-transform duration-300">
              آرتاکالا
            </h2>
          </Link>
          
          <div className="flex items-center justify-center gap-4 mb-6">
            <div className="w-16 h-px bg-gradient-to-l from-emerald-400 to-transparent" />
            <p className="text-emerald-400/80 font-light text-lg">هنر نزد ایرانیان است و بس.</p>
            <div className="w-16 h-px bg-gradient-to-r from-emerald-400 to-transparent" />
          </div>
          
          <p className="max-w-2xl text-gray-400 leading-relaxed text-sm md:text-base">
            فروشگاه تخصصی ابزار با بهترین قیمت، تضمین کیفیت و ارسال سریع. 
            همراه مطمئن شما در خرید آنلاین. با بیش از یک دهه تجربه درخشان در خدمت شما عزیزان هستیم.
          </p>
        </div>

        {/* خط جداکننده با آیکون‌های اجتماعی */}
        <div className="flex flex-row gap-4 items-center w-full mb-16">
          <div className="border-b border-gray-700 w-full" />
          <div className="flex flex-row gap-3">
            {footerData.social.map((item, index) => (
              <a
                key={index}
                href={item.href}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex justify-center items-center bg-emerald-500/10 text-emerald-400 w-10 h-10 rounded-full hover:bg-emerald-500 hover:text-white transition-all duration-300 hover:scale-110 hover:rotate-6"
                title={item.label}
              >
                <span className="text-lg group-hover:scale-110 transition-transform">
                  {item.icon}
                </span>
              </a>
            ))}
          </div>
          <div className="border-b border-gray-700 w-full" />
        </div>

        {/* لینک‌های فوتر - گرید ۴ ستونه */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          
          {/* لینک های مهم */}
          <div className="space-y-5">
            <div className="flex items-center gap-2">
              <span className="text-emerald-400 font-bold text-lg">لینک های مهم</span>
              <div className="w-8 h-px bg-emerald-400/50" />
            </div>
            <ul className="space-y-3">
              {footerData.importantLinks.map((link, index) => (
                <li key={index}>
                  <Link
                    href={link.href}
                    className="group flex items-center gap-2 text-gray-400 hover:text-emerald-400 transition-all duration-300 hover:translate-x-1"
                  >
                    <FaChevronLeft className="text-xs opacity-0 group-hover:opacity-100 transition-all duration-300 -translate-x-2 group-hover:translate-x-0" />
                    <span>{link.label}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* دسترسی سریع */}
          <div className="space-y-5">
            <div className="flex items-center gap-2">
              <span className="text-emerald-400 font-bold text-lg">دسترسی سریع</span>
              <div className="w-8 h-px bg-emerald-400/50" />
            </div>
            <ul className="space-y-3">
              {footerData.quickLinks.map((link, index) => (
                <li key={index}>
                  <Link
                    href={link.href}
                    className="group flex items-center gap-2 text-gray-400 hover:text-emerald-400 transition-all duration-300 hover:translate-x-1"
                  >
                    <FaChevronLeft className="text-xs opacity-0 group-hover:opacity-100 transition-all duration-300 -translate-x-2 group-hover:translate-x-0" />
                    <span>{link.label}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* مسیرهای ارتباطی */}
          <div className="space-y-5">
            <div className="flex items-center gap-2">
              <span className="text-emerald-400 font-bold text-lg">مسیرهای ارتباطی</span>
              <div className="w-8 h-px bg-emerald-400/50" />
            </div>
            <ul className="space-y-4">
              <li className="flex items-start gap-3 group">
                <span className="flex justify-center items-center w-8 h-8 rounded-full bg-emerald-500/10 text-emerald-400 group-hover:bg-emerald-500 group-hover:text-white transition-all duration-300 flex-shrink-0">
                  <FaMapMarkerAlt className="text-sm" />
                </span>
                <span className="text-gray-400 text-sm leading-relaxed group-hover:text-gray-300 transition-colors">
                  {footerData.contact.address}
                </span>
              </li>
              <li className="flex items-center gap-3 group">
                <span className="flex justify-center items-center w-8 h-8 rounded-full bg-emerald-500/10 text-emerald-400 group-hover:bg-emerald-500 group-hover:text-white transition-all duration-300">
                  <FaPhoneAlt className="text-sm" />
                </span>
                <div className="flex flex-col">
                  <a href={`tel:${footerData.contact.phone.replace(/-/g, "")}`} className="text-gray-400 group-hover:text-emerald-400 transition-colors">
                    {footerData.contact.phone}
                  </a>
                  <a href={`tel:${footerData.contact.mobile.replace(/-/g, "")}`} className="text-gray-400 group-hover:text-emerald-400 transition-colors text-sm">
                    {footerData.contact.mobile}
                  </a>
                </div>
              </li>
              <li className="flex items-center gap-3 group">
                <span className="flex justify-center items-center w-8 h-8 rounded-full bg-emerald-500/10 text-emerald-400 group-hover:bg-emerald-500 group-hover:text-white transition-all duration-300">
                  <HiOutlineMail className="text-lg" />
                </span>
                <a href={`mailto:${footerData.contact.email}`} className="text-gray-400 group-hover:text-emerald-400 transition-colors text-sm">
                  {footerData.contact.email}
                </a>
              </li>
              <li className="flex items-center gap-3 group">
                <span className="flex justify-center items-center w-8 h-8 rounded-full bg-emerald-500/10 text-emerald-400 group-hover:bg-emerald-500 group-hover:text-white transition-all duration-300">
                  <TbClockHour4 className="text-lg" />
                </span>
                <span className="text-gray-400 group-hover:text-gray-300 transition-colors text-sm">
                  {footerData.contact.workingHours}
                </span>
              </li>
            </ul>
          </div>

          {/* نماد اعتماد */}
          <div className="space-y-5">
            <div className="flex items-center gap-2">
              <span className="text-emerald-400 font-bold text-lg">نماد اعتماد</span>
              <div className="w-8 h-px bg-emerald-400/50" />
            </div>
            <a
              referrerPolicy="origin"
              target="_blank"
              rel="noopener noreferrer"
              href="https://trustseal.enamad.ir/?id=369698&Code=I6YLcWz8xiSgXqO0fwksAnbpTDwBmbZA"
              className="inline-block bg-white/5 rounded-xl p-3 hover:bg-white/10 transition-all duration-300 hover:scale-105"
            >
              <img
                referrerPolicy="origin"
                src="https://trustseal.enamad.ir/logo.aspx?id=369698&Code=I6YLcWz8xiSgXqO0fwksAnbpTDwBmbZA"
                alt="نماد اعتماد الکترونیکی"
                className="h-20 w-auto"
              />
            </a>
          </div>
        </div>
      </div>

      {/* بخش پایینی - کپی‌رایت */}
      <div className="border-t border-gray-800 bg-black/20 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-sm text-gray-500">
              © {currentYear} تمام حقوق نزد <span className="text-emerald-400">آرتاکالا</span> محفوظ است.
            </p>
            
            <div className="flex gap-6">
              <a href="#" className="text-xs text-gray-600 hover:text-emerald-400 transition-colors">
                حریم خصوصی
              </a>
              <a href="#" className="text-xs text-gray-600 hover:text-emerald-400 transition-colors">
                قوانین و مقررات
              </a>
              <a href="#" className="text-xs text-gray-600 hover:text-emerald-400 transition-colors">
                شرایط استفاده
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;