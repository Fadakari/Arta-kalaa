import Image from "next/image";
import { Feature } from "@/types";

interface FeatureCardProps {
  feature: Feature;
  index: number;
}

export default function FeatureCard({ feature, index }: FeatureCardProps) {
  return (
    <div
      className="group relative flex items-center gap-4 p-5 rounded-2xl bg-white shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1 cursor-default overflow-hidden"
      style={{
        animationDelay: `${index * 100}ms`,
        animation: "fadeInUp 0.6s ease-out forwards",
      }}
    >
      {/* پس‌زمینه سفید */}
      <div className="absolute inset-0 bg-white opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      
      {/* آیکون */}
      <div className="relative w-14 h-14 sm:w-16 sm:h-16 lg:w-20 lg:h-20 flex-shrink-0">
        <div className="absolute inset-0 bg-gray-100 rounded-2xl rotate-6 group-hover:rotate-12 transition-transform duration-300" />
        <Image
          width={200}
          height={200}
          src={feature.img}
          alt={feature.title}
          className="relative w-full h-auto object-contain drop-shadow-md"
        />
      </div>
      
      {/* متن */}
      <div className="relative">
        <h3 className="text-sm sm:text-base lg:text-lg font-bold text-gray-800 mb-1 group-hover:text-gray-900 transition-colors">
          {feature.title}
        </h3>
        <p className="text-gray-500 text-xs sm:text-sm m-0">
          {feature.desc}
        </p>
      </div>
    </div>
  );
}