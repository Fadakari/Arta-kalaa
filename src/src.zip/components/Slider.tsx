"use client";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/effect-coverflow";
import "swiper/css/pagination";
import { ReactNode, useRef, useState } from "react";
import { GoChevronLeft, GoChevronRight } from "react-icons/go";
import { Autoplay } from "swiper/modules";
import ErrorMessage from "./ErrorMessage";

function ProductSlider({
  items,
  Card,
  spaceBetween = 20,
  className,
  slidesPerView = 4,
  firstItem,
  navigation = true,
  customNavigation,
}: {
  items: any[];
  Card: any;
  spaceBetween?: number;
  slidesPerView?: number;
  className?: string;
  firstItem?: ReactNode;
  navigation?: boolean;
  customNavigation?: boolean;
}) {
  const swiperRef: any = useRef(null);
  const [isBeginning, setIsBeginning] = useState(true);
  const [isEnd, setIsEnd] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const safeItems = Array.isArray(items) ? items : [];

  if (safeItems.length === 0) {
    return <ErrorMessage />;
  }

  const enableLoop = items.length > slidesPerView + 1;

  return items?.length > 0 ? (
    <div
      className="relative w-full h-full group/slider"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <Swiper
        navigation={false}
        spaceBetween={spaceBetween}
        onSwiper={(swiper) => {
          swiperRef.current = swiper;
          setIsBeginning(swiper.isBeginning);
          setIsEnd(swiper.isEnd);
        }}
        onSlideChange={(swiper) => {
          setIsBeginning(swiper.isBeginning);
          setIsEnd(swiper.isEnd);
        }}
        loop={enableLoop}
        autoplay={
          !isHovered
            ? {
                delay: 4000,
                disableOnInteraction: false,
                pauseOnMouseEnter: true,
              }
            : false
        }
        modules={[Autoplay]}
        breakpoints={{
          0: { slidesPerView: 1, spaceBetween: 10 },
          640: { slidesPerView: 2, spaceBetween: 15 },
          1024: { slidesPerView: 3, spaceBetween: 20 },
          1440: { slidesPerView: slidesPerView, spaceBetween: spaceBetween },
        }}
        className="!pb-4"
      >
        {firstItem && (
          <SwiperSlide className="p-3 hidden md:block">{firstItem}</SwiperSlide>
        )}

        {items.map((item: any, index: number) => (
          <SwiperSlide key={item.id || index} className="p-2">
            <Card item={item} />
          </SwiperSlide>
        ))}
      </Swiper>

      {/* دکمه‌های ناوبری */}
      {navigation && (
        <>
          {/* دکمه قبلی - بیرون کارت، وسط ارتفاع */}
          <button
            onClick={() => swiperRef.current?.slidePrev()}
            className="absolute top-1/2 -right-7 -translate-y-1/2 z-20 
              w-12 h-12 rounded-full bg-white shadow-lg border border-gray-200
              flex items-center justify-center text-gray-600 hover:text-blue-500 hover:border-blue-400
              transition-all duration-300 hover:shadow-xl hover:scale-110 active:scale-95"
            aria-label="Previous"
          >
            <GoChevronRight className="size-6" />
          </button>

          {/* دکمه بعدی - بیرون کارت، وسط ارتفاع */}
          <button
            onClick={() => swiperRef.current?.slideNext()}
            className="absolute top-1/2 -left-7 -translate-y-1/2 z-20 
              w-12 h-12 rounded-full bg-white shadow-lg border border-gray-200
              flex items-center justify-center text-gray-600 hover:text-blue-500 hover:border-blue-400
              transition-all duration-300 hover:shadow-xl hover:scale-110 active:scale-95"
            aria-label="Next"
          >
            <GoChevronLeft className="size-6" />
          </button>
        </>
      )}
    </div>
  ) : (
    "خطا در دریافت اطلاعات"
  );
}

export default ProductSlider;