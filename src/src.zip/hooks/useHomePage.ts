"use client";

import { useState, useEffect } from "react";
import ProductType from "@/types/product";
import {
  GetFeaturedProducts,
  GetLatestProducts,
  GetProducts,
} from "@/services/shopActions";
import { GetLatestArticles } from "@/services/blogActions";

interface HomePageData {
  products: ProductType[];
  latestProducts: ProductType[];
  featuredProducts: ProductType[];
  latestArticles: any[];
  isLoading: boolean;
  error: string | null;
}

export const useHomePage = (): HomePageData => {
  const [data, setData] = useState<HomePageData>({
    products: [],
    latestProducts: [],
    featuredProducts: [],
    latestArticles: [],
    isLoading: true,
    error: null,
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const results = await Promise.allSettled([
          GetProducts({}, 1, true),
          GetLatestProducts(),
          GetFeaturedProducts(),
          GetLatestArticles(),
        ]);

        const productsVal = results[0].status === "fulfilled" ? results[0].value : null;
        const latestVal = results[1].status === "fulfilled" ? results[1].value : null;
        const featuredVal = results[2].status === "fulfilled" ? results[2].value : null;
        const articlesVal = results[3].status === "fulfilled" ? results[3].value : null;

        const products = productsVal?.results || [];
        
        // ✅ FALLBACK - با optional chaining
        const latestResults = latestVal?.results;
        const latestProducts = 
          latestResults && latestResults.length > 0 
            ? latestResults 
            : products.slice(0, 8);

        const featuredProducts = Array.isArray(featuredVal)
          ? featuredVal
          : featuredVal?.data || featuredVal?.results || [];

        const latestArticles = 
          articlesVal?.data?.results || 
          articlesVal?.data || 
          articlesVal?.results || 
          [];

        setData({
          products,
          latestProducts,
          featuredProducts,
          latestArticles,
          isLoading: false,
          error: null,
        });
      } catch (error) {
        setData((prev) => ({
          ...prev,
          isLoading: false,
          error: "خطا در دریافت اطلاعات",
        }));
        console.error("Fetch failed:", error);
      }
    };

    fetchData();
  }, []);

  return data;
};